package com.raju.javabaseproject.ui.adapters.delegate.base

import android.view.ViewGroup
import androidx.annotation.NonNull

interface AdapterDelegate<T> {
    fun isForViewType(@NonNull items: T, position: Int): Boolean
    fun onCreateViewHolder(parent: ViewGroup): androidx.recyclerview.widget.RecyclerView.ViewHolder
    fun onBindViewHolder(@NonNull items: T, position: Int, holder: androidx.recyclerview.widget.RecyclerView.ViewHolder)
    fun setDelegateClickListener(delegateClickListener: DelegateClickListener)
}