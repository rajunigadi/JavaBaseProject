package com.raju.javabaseproject.data.model

interface ListItem
