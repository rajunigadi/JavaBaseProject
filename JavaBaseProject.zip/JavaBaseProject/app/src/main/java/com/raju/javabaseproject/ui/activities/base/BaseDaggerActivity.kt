package com.raju.javabaseproject.ui.activities.base

import com.raju.javabaseproject.viewmodels.base.BaseViewModel

import javax.inject.Inject

class BaseDaggerActivity<V : BaseViewModel> : BaseActivity() {

    @Inject
    internal var viewModel: V? = null

    override fun onDestroy() {
        super.onDestroy()
        if (viewModel != null) {
            viewModel!!.destroy()
        }
    }
}
