package com.raju.javabaseproject.ui.fragments

import android.arch.lifecycle.Observer
import android.content.Context
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View

import com.raju.javabaseproject.R
import com.raju.javabaseproject.data.model.User
import com.raju.javabaseproject.ui.adapters.UserAdapter
import com.raju.javabaseproject.ui.adapters.base.ClickableItemTarget
import com.raju.javabaseproject.ui.adapters.base.ItemClickListener
import com.raju.javabaseproject.ui.adapters.delegate.base.DelegatingAdapter
import com.raju.javabaseproject.ui.fragments.base.BaseDaggerFragment
import com.raju.javabaseproject.viewmodels.UserViewModel

import javax.inject.Inject

import butterknife.BindView
import dagger.android.support.AndroidSupportInjection
import timber.log.Timber

class UserFragment : BaseDaggerFragment<UserViewModel>(R.layout.fragment_user, "User"), ItemClickListener<User> {

    @BindView(R.id.recycler_view)
    internal var recyclerView: RecyclerView? = null

    @Inject
    internal var adapter: UserAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
    }

    override fun onAttach(context: Context?) {
        AndroidSupportInjection.inject(this)
        super.onAttach(context)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupAdapter(recyclerView!!)

        viewModel!!.result.observe(this, Observer { users ->
            hideLoading()
            adapter!!.refactorItems(users)
            recyclerView!!.visibility = View.VISIBLE
        })

        viewModel!!.error.observe(this, Observer { s ->
            hideLoading()
            showSnackBar(s)
        })
    }

    override fun onStart() {
        super.onStart()
        if (viewModel != null) {
            viewModel!!.init()
            viewModel!!.getUsers()
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel!!.destroy()
    }

    fun showLoading() {

    }

    fun hideLoading() {

    }

    override fun onClick(item: User, position: Int, view: View) {
        Timber.d("User clicked")
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(activity)
        recyclerView!!.layoutManager = layoutManager
    }

    private fun setupAdapter(recyclerView: RecyclerView) {
        if (recyclerView.adapter !== adapter) {
            recyclerView.adapter = adapter

            if (adapter is ClickableItemTarget<*>) {
                val target = adapter as ClickableItemTarget<User>?
                target!!.setItemClickListener(this)
            }

            if (adapter is DelegatingAdapter<*>) {
                adapter!!.setup()
            }
        }
    }

    companion object {

        fun newInstance(): UserFragment {
            return UserFragment()
        }
    }
}