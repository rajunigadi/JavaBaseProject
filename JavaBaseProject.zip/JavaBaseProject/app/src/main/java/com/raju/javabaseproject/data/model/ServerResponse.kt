package com.raju.javabaseproject.data.model

class ServerResponse {

    var status: Int = 0
    var message: String? = null
}
