package com.raju.javabaseproject.data.model

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.os.Parcel
import android.os.Parcelable

import com.google.gson.annotations.SerializedName

@Entity
class User : Parcelable, ListItem {

    @PrimaryKey
    @SerializedName("id")
    var id: Int = 0

    @SerializedName("login")
    var login: String? = null

    @SerializedName("avatar_url")
    var avatarUrl: String? = null

    @SerializedName("url")
    var url: String? = null

    @SerializedName("repos_url")
    var reposUrl: String? = null

    constructor() {

    }

    protected constructor(`in`: Parcel) {
        id = `in`.readInt()
        login = `in`.readString()
        avatarUrl = `in`.readString()
        url = `in`.readString()
        reposUrl = `in`.readString()
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeInt(id)
        dest.writeString(login)
        dest.writeString(avatarUrl)
        dest.writeString(url)
        dest.writeString(reposUrl)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object {

        val CREATOR: Parcelable.Creator<User> = object : Parcelable.Creator<User> {
            override fun createFromParcel(`in`: Parcel): User {
                return User(`in`)
            }

            override fun newArray(size: Int): Array<User> {
                return arrayOfNulls(size)
            }
        }
    }
}
