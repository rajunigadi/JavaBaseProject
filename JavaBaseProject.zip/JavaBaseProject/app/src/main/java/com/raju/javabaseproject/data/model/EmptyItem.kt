package com.raju.javabaseproject.data.model

class EmptyItem : ListItem
