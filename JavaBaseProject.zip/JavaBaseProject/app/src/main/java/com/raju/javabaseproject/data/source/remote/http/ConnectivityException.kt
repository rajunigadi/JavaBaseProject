package com.raju.javabaseproject.data.source.remote.http

import java.io.IOException


class ConnectivityException : IOException() {

    override fun getMessage(): String {
        return "No Internet Connection"
    }

}

