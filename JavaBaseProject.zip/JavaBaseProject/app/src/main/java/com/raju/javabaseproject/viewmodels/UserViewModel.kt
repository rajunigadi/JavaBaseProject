package com.raju.javabaseproject.viewmodels

import android.arch.lifecycle.MutableLiveData

import com.google.gson.Gson
import com.raju.javabaseproject.data.model.ErrorResponse
import com.raju.javabaseproject.data.model.User
import com.raju.javabaseproject.data.source.UserRepository
import com.raju.javabaseproject.viewmodels.base.BaseViewModel

import javax.inject.Inject

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import okhttp3.ResponseBody
import retrofit2.HttpException

class UserViewModel @Inject
internal constructor(private val repository: UserRepository, private val gson: Gson) : BaseViewModel() {

    var result: MutableLiveData<List<User>> = MutableLiveData()
    var error: MutableLiveData<String> = MutableLiveData()

    fun getUsers() {
        compositeDisposable!!.add(repository.users
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ users -> result.postValue(users) }, { throwable ->
                    var errorMessage: String? = null
                    try {
                        if (throwable is HttpException) {
                            val body = throwable.response().errorBody()
                            val errorResponse = gson.fromJson(body!!.string(), ErrorResponse::class.java)
                            if (errorResponse != null) {
                                errorMessage = errorResponse.message
                            }
                        }
                    } catch (e: Exception) {
                        // errorMessage = e.getMessage();
                    }

                    error.postValue(errorMessage)
                }))
    }
}
