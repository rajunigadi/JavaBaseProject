package com.raju.javabaseproject.ui.activities.base

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast

import com.raju.javabaseproject.R

import javax.inject.Inject

import dagger.android.AndroidInjection
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector


open class BaseActivity : AppCompatActivity(), HasSupportFragmentInjector {

    @Inject
    internal var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
    }

    override fun supportFragmentInjector(): AndroidInjector<Fragment>? {
        return fragmentDispatchingAndroidInjector
    }

    protected fun showSnackBar(message: String, hasAction: Boolean) {
        showSnackBar(message, hasAction, null)
    }

    @JvmOverloads
    protected fun showSnackBar(message: String, isAction: Boolean = false, action: String? = null) {
        var action = action
        val view = window.decorView.findViewById<View>(android.R.id.content)
        if (view != null) {
            val snackbar = Snackbar.make(view, message, Snackbar.LENGTH_LONG)
            if (isAction) {
                snackbar.duration = Snackbar.LENGTH_INDEFINITE
                if (TextUtils.isEmpty(action)) action = /*getResources().getString(R.string.dismiss)*/ "Dismiss"
                snackbar.setAction(action) { snackbar.dismiss() }
            }
            snackbar.setActionTextColor(Color.WHITE)
            val sbView = snackbar.view
            val textView = sbView.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            textView.setTextColor(Color.WHITE)
            snackbar.show()
        } else {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    protected fun hideKeyboard() {
        if (currentFocus != null && currentFocus!!.windowToken != null) {
            val ime = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            ime.hideSoftInputFromWindow(currentFocus!!.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }
    }
}
