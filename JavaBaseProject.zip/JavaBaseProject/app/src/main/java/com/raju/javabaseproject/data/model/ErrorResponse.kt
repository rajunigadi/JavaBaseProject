package com.raju.javabaseproject.data.model

class ErrorResponse {

    var status: Int = 0
    var message: String? = null
}
