package com.raju.javabaseproject.data.model

class HeaderItem : ListItem {

    var header: String? = null
    var subHeader: String? = null
}
